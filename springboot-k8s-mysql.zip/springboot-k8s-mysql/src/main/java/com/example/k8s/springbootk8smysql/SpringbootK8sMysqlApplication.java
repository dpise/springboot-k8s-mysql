package com.example.k8s.springbootk8smysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootK8sMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootK8sMysqlApplication.class, args);
	}

}
