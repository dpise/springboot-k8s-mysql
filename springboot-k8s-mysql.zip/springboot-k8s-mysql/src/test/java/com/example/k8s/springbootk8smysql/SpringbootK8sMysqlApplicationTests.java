package com.example.k8s.springbootk8smysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootK8sMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
